from coinbase.rest import RESTClient


def get_accounts(api_key: str, api_secret: str, portfolio_id: str):
    # Replace with your own API Keys and ensure you use the correct key format (organizations/{org_id}/apiKeys/{key_id})
    if api_key == "":
        raise ValueError("Coinbase API Key is not set.")
    client = RESTClient(api_key=api_key, api_secret=api_secret)

    portfolio = client.get_portfolio_breakdown(portfolio_id)
    # Get account balances
    spot_positions = portfolio.to_dict()["breakdown"]["spot_positions"]
    for position in spot_positions:
        yield position
